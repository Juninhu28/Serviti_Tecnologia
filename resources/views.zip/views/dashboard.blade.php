<x-layouts.app title="Dashboard">
    <div class="p-6">
        <h1 class="text-xl font-bold">Bem-vindo ao sistema Serviti!</h1>
        <p class="text-gray-600 mt-2">Escolha uma das opções no menu ao lado.</p>
    </div>
</x-layouts.app>
